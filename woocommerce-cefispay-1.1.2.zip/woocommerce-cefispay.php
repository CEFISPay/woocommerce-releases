<?php
/**
 * Plugin Name: CEFIS Pay for WooCommerce
 * Plugin URI: http://github.com/cefispay/woocommerce
 * Description: Gateway de pagamento CEFIS Pay para WooCommerce.
 * Author: CEFIS Pay
 * Author URI: https://cefispay.com.br/
 * Version: 1.1.2
 * License: GPLv2 or later
 * Text Domain: woocommerce-cefispay
 *
 * @package WooCommerce_CefisPay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WC_CefisPay' ) ) :

	/**
	 * WooCommerce WC_CefisPay main class.
	 */
	class WC_CefisPay {

		/**
		 * Plugin version.
		 *
		 * @var string
		 */
		const VERSION = '1.1.2';

		/**
		 * Instance of this class.
		 *
		 * @var object
		 */
		protected static $instance = null;

		/**
		 * Initialize the plugin public actions.
		 */
		private function __construct() {

			// Checks with WooCommerce is installed.
			if ( class_exists( 'WC_Payment_Gateway' ) ) {
				$this->includes();

				add_filter( 'woocommerce_payment_gateways', array( $this, 'add_gateway' ) );
				add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'plugin_action_links' ) );
			} else {
				add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
			}
		}

		/**
		 * Return an instance of this class.
		 *
		 * @return object A single instance of this class.
		 */
		public static function get_instance() {
			// If the single instance hasn't been set, set it now.
			if ( null === self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}

		/**
		 * Includes.
		 */
		private function includes() {
			include_once dirname( __FILE__ ) . '/includes/class-wc-cefispay-api.php';
			include_once dirname( __FILE__ ) . '/includes/class-wc-cefispay-my-account.php';
			// Boleto desabilitado
			// include_once dirname( __FILE__ ) . '/includes/class-wc-cefispay-banking-ticket-gateway.php';
			include_once dirname( __FILE__ ) . '/includes/class-wc-cefispay-credit-card-gateway.php';
		}

		/**
		 * Get templates path.
		 *
		 * @return string
		 */
		public static function get_templates_path() {
			return plugin_dir_path( __FILE__ ) . 'templates/';
		}

		/**
		 * Add the gateway to WooCommerce.
		 *
		 * @param  array $methods WooCommerce payment methods.
		 *
		 * @return array
		 */
		public function add_gateway( $methods ) {
			$methods[] = 'WC_CefisPay_Banking_Ticket_Gateway';
			$methods[] = 'WC_CefisPay_Credit_Card_Gateway';

			return $methods;
		}

		/**
		 * Action links.
		 *
		 * @param  array $links Plugin links.
		 *
		 * @return array
		 */
		public function plugin_action_links( $links ) {
			$plugin_links = array();

			$banking_ticket = 'WC_CefisPay_banking_ticket_gateway';
			$credit_card    = 'WC_CefisPay_credit_card_gateway';

			// Boleto desabilitado
			// $plugin_links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $banking_ticket ) ) . '">' . __( 'Bank Slip Settings', 'woocommerce-cefispay' ) . '</a>';

			$plugin_links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=' . $credit_card ) ) . '">' . __( 'Credit Card Configs', 'woocommerce-cefispay' ) . '</a>';

			return array_merge( $plugin_links, $links );
		}

		/**
		 * WooCommerce fallback notice.
		 */
		public function woocommerce_missing_notice() {
			include dirname( __FILE__ ) . '/includes/admin/views/html-notice-missing-woocommerce.php';
		}
	}

	add_action( 'plugins_loaded', array( 'WC_CefisPay', 'get_instance' ) );

endif;
