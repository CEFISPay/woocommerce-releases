<?php
/**
 * Notice: Currency not supported.
 *
 * @package WooCommerce_CefisPay/Admin/Notices
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div class="error inline">
	<p><strong><?php esc_html_e( 'CEFIS Pay Disabled', 'woocommerce-cefispay' ); ?></strong>: <?php printf( wp_kses( __( 'Moeda %s não é suportada. Apenas Real Brasileiro é suportado.', 'woocommerce-cefispay' ), array( 'code' => array() ) ), '<code>' . esc_html( get_woocommerce_currency() ) . '</code>' ); ?>
	</p>
</div>

<?php
