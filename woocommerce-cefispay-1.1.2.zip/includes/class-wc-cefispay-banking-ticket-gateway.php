<?php
/**
 * CEFIS Pay Banking Ticket gateway
 *
 * @package WooCommerce_CefisPay/Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC_CefisPay_Banking_Ticket_Gateway class.
 *
 * @extends WC_Payment_Gateway
 */
class WC_CefisPay_Banking_Ticket_Gateway extends WC_Payment_Gateway {

	/**
	 * Constructor for the gateway.
	 */
	public function __construct() {
		$this->id                   = 'cefispay-banking-ticket';
		$this->icon                 = apply_filters( 'wc_cefispay_banking_ticket_icon', false );
		$this->has_fields           = true;
		$this->method_title         = __( 'CEFIS Pay - Banking Ticket', 'woocommerce-cefispay' );
		$this->method_description   = __( 'Accept banking ticket payments using CEFIS Pay.', 'woocommerce-cefispay' );
		$this->view_transaction_url = 'https://app.cefispay.com.br/#/transactions/%s';

		// Load the form fields.
		$this->init_form_fields();

		// Load the settings.
		$this->init_settings();

		// Define user set variables.
		$this->title          = $this->get_option( 'title' );
		$this->description    = $this->get_option( 'description' );
		$this->api_key        = $this->get_option( 'api_key' );
		$this->debug          = $this->get_option( 'debug' );
		$this->async          = $this->get_option( 'async' );

		// Active logs.
		if ( 'yes' === $this->debug ) {
			$this->log = new WC_Logger();
		}

		// Set the API.
		$this->api = new WC_CefisPay_API( $this );

		// Actions.
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
		add_action( 'woocommerce_email_after_order_table', array( $this, 'email_instructions' ), 10, 3 );
		add_action( 'woocommerce_api_wc_cefispay_banking_ticket_gateway', array( $this, 'ipn_handler' ) );
	}

	/**
	 * Admin page.
	 */
	public function admin_options() {
		include dirname( __FILE__ ) . '/admin/views/html-admin-page.php';
	}

	/**
	 * Check if the gateway is available to take payments.
	 *
	 * @return bool
	 */
	public function is_available() {
		return parent::is_available() && ! empty( $this->api_key ) && $this->api->using_supported_currency();
	}

	/**
	 * Settings fields.
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'   => __( 'Enable/Disable', 'woocommerce-cefispay' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable CEFIS Pay Banking Ticket', 'woocommerce-cefispay' ),
				'default' => 'no',
			),
			'title' => array(
				'title'       => __( 'Title', 'woocommerce-cefispay' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce-cefispay' ),
				'desc_tip'    => true,
				'default'     => __( 'Banking Ticket', 'woocommerce-cefispay' ),
			),
			'description' => array(
				'title'       => __( 'Description', 'woocommerce-cefispay' ),
				'type'        => 'textarea',
				'description' => __( 'This controls the description which the user sees during checkout.', 'woocommerce-cefispay' ),
				'desc_tip'    => true,
				'default'     => __( 'Pay with Banking Ticket', 'woocommerce-cefispay' ),
			),
			'integration' => array(
				'title'       => __( 'Integration Settings', 'woocommerce-cefispay' ),
				'type'        => 'title',
				'description' => '',
			),
			'api_key' => array(
				'title'             => __( 'CEFIS Pay API Key', 'woocommerce-cefispay' ),
				'type'              => 'text',
				'description'       => sprintf( __( 'Please enter your CEFIS Pay API Key. This is needed to process the payment and notifications. To get your API key please contact our team in %s.', 'woocommerce-cefispay' ), '<a href="mailto:ti@cefispay.com.br">ti@cefispay.com.br</a>' ),
				'default'           => '',
				'custom_attributes' => array(
					'required' => 'required',
				),
			),
			'merchant_id' => array(
				'title'             => __( 'CEFIS Pay Merchant ID', 'woocommerce-cefispay' ),
				'type'              => 'text',
				'description'       => sprintf( __( 'Please enter your CEFIS Pay Merchant ID. This is needed to process the payment. Is possible get your Merchant ID in %s.', 'woocommerce-cefispay' ), '<a href="https://app.cefispay.com.br/">' . __( 'CEFIS Pay Dashboard > My Account page', 'woocommerce-cefispay' ) . '</a>' ),
				'default'           => '',
				'custom_attributes' => array(
					'required' => 'required',
				),
			),
			'testing' => array(
				'title'       => __( 'Gateway Testing', 'woocommerce-cefispay' ),
				'type'        => 'title',
				'description' => '',
			),
			'debug' => array(
				'title'       => __( 'Debug Log', 'woocommerce-cefispay' ),
				'type'        => 'checkbox',
				'label'       => __( 'Enable logging', 'woocommerce-cefispay' ),
				'default'     => 'no',
				'description' => sprintf( __( 'Log CEFIS Pay events, such as API requests. You can check the log in %s', 'woocommerce-cefispay' ), '<a href="' . esc_url( admin_url( 'admin.php?page=wc-status&tab=logs&log_file=' . esc_attr( $this->id ) . '-' . sanitize_file_name( wp_hash( $this->id ) ) . '.log' ) ) . '">' . __( 'System Status &gt; Logs', 'woocommerce-cefispay' ) . '</a>' ),
			),
		);
	}

	/**
	 * Payment fields.
	 */
	public function payment_fields() {
		if ( $description = $this->get_description() ) {
			echo wp_kses_post( wpautop( wptexturize( $description ) ) );
		}

		wc_get_template(
			'banking-ticket/checkout-instructions.php',
			array(),
			'woocommerce/cefispay/',
			WC_CefisPay::get_templates_path()
		);
	}

	/**
	 * Process the payment.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @return array Redirect data.
	 */
	public function process_payment( $order_id ) {
		return $this->api->process_regular_payment( $order_id );
	}

	/**
	 * Thank You page message.
	 *
	 * @param int $order_id Order ID.
	 */
	public function thankyou_page( $order_id ) {
		$order = wc_get_order( $order_id );
		$data  = get_post_meta( $order_id, '_wc_cefispay_transaction_data', true );

		if ( isset( $data['boleto_url'] ) && in_array( $order->get_status(), array( 'processing', 'on-hold' ), true ) ) {
			$template = 'no' === $this->async ? 'payment' : 'async';

			wc_get_template(
				'banking-ticket/' . $template . '-instructions.php',
				array(
					'url' => $data['boleto_url'],
				),
				'woocommerce/cefispay/',
				WC_CefisPay::get_templates_path()
			);
		}
	}

	/**
	 * Add content to the WC emails.
	 *
	 * @param  object $order         Order object.
	 * @param  bool   $sent_to_admin Send to admin.
	 * @param  bool   $plain_text    Plain text or HTML.
	 *
	 * @return string                Payment instructions.
	 */
	public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
		if ( $sent_to_admin || ! in_array( $order->get_status(), array( 'processing', 'on-hold' ), true ) || $this->id !== $order->payment_method ) {
			return;
		}

		$data = get_post_meta( $order->id, '_wc_cefispay_transaction_data', true );

		if ( isset( $data['boleto_url'] ) ) {
			$email_type = $plain_text ? 'plain' : 'html';

			wc_get_template(
				'banking-ticket/emails/' . $email_type . '-instructions.php',
				array(
					'url' => $data['boleto_url'],
				),
				'woocommerce/cefispay/',
				WC_CefisPay::get_templates_path()
			);
		}
	}

	/**
	 * IPN handler.
	 */
	public function ipn_handler() {
		$this->api->ipn_handler();
	}
}
