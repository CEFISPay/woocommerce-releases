<?php
/**
 * CEFIS Pay API
 *
 * @package WooCommerce_CefisPay/API
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC_CefisPay_API class.
 */
class WC_CefisPay_API {

	/**
	 * API URL.
	 */
	const API_URL = 'https://payments.cefis.com.br/api/v1/';

	/**
	 * Gateway class.
	 *
	 * @var WC_Payment_Gateway
	 */
	protected $gateway;

	/**
	 * API URL.
	 *
	 * @var string
	 */
	protected $api_url = 'https://payments.cefis.com.br/api/v1/';

	/**
	 * JS Library URL.
	 *
	 * @var string
	 */
	protected $js_url = 'https://payments.cefis.com.br/assets/js/checkout.js';

	/**
	 * Checkout JS Library URL.
	 *
	 * @var string
	 */
	protected $checkout_js_url = 'https://payments.cefis.com.br/js/checkout.js';

	/**
	 * Constructor.
	 *
	 * @param WC_Payment_Gateway $gateway Gateway instance.
	 */
	public function __construct( $gateway = null ) {
		$this->gateway = $gateway;
	}

	/**
	 * Get API URL.
	 *
	 * @return string
	 */
	public function get_api_url() {
		return $this->api_url;
	}

	/**
	 * Get JS Library URL.
	 *
	 * @return string
	 */
	public function get_js_url() {
		return $this->js_url;
	}

	/**
	 * Get Checkout JS Library URL.
	 *
	 * @return string
	 */
	public function get_checkout_js_url() {
		return $this->checkout_js_url;
	}

	/**
	 * Returns a bool that indicates if currency is amongst the supported ones.
	 *
	 * @return bool
	 */
	public function using_supported_currency() {
		return 'BRL' === get_woocommerce_currency();
	}

	/**
	 * Only numbers.
	 *
	 * @param  string|int $string String to convert.
	 *
	 * @return string|int
	 */
	protected function only_numbers( $string ) {
		return preg_replace( '([^0-9])', '', $string );
	}

	/**
	 * Get the smallest installment amount.
	 *
	 * @return int
	 */
	public function get_smallest_installment() {
		return ( 5 > $this->gateway->smallest_installment ) ? 500 : wc_format_decimal( $this->gateway->smallest_installment ) * 100;
	}

	/**
	 * Get the interest rate.
	 *
	 * @return float
	 */
	public function get_interest_rate() {
		return wc_format_decimal( $this->gateway->interest_rate );
	}

	/**
	 * Do requests in the Cefis Pay API.
	 *
	 * @param  string $endpoint API Endpoint.
	 * @param  string $method   Request method.
	 * @param  array  $data     Request data.
	 * @param  array  $headers  Request headers.
	 *
	 * @return array            Request response.
	 */
	protected function do_request( $endpoint, $method = 'POST', $data = array(), $headers = array() ) {
		$params = array(
			'method'  => $method,
			'timeout' => 60,
		);

		if ( ! empty( $data ) ) {
			$params['body'] = json_encode($data);
			$params["data_format"] = 'body';
		}

		// Cefis Pay user-agent and api version.
		$x_cefispay_useragent = 'cefispay-woocommerce/' . WC_CefisPay::VERSION;

		if ( defined( 'WC_VERSION' ) ) {
			$x_cefispay_useragent .= ' woocommerce/' . WC_VERSION;
		}

		$x_cefispay_useragent .= ' wordpress/' . get_bloginfo( 'version' );
		$x_cefispay_useragent .= ' php/' . phpversion();

		$params['headers'] = [
			'Authorization' => 'Bearer ' . $this->gateway->api_key,
			'User-Agent' => $x_cefispay_useragent,
			'X-CefisPay-User-Agent' => $x_cefispay_useragent,
			'X-CefisPay-Version' => '2020-02-12',
			'Content-Type' => 'application/json',
			'Accept' => 'application/json'
		];

		if ( ! empty( $headers ) ) {
			$params['headers'] = array_merge( $params['headers'], $headers );
		}

		$fullEndpoint = $this->get_api_url() . $endpoint;

		$this->gateway->log->add( $this->gateway->id, 'Doing request to ' . $fullEndpoint . '...' );

		$params['sslverify'] = false;

		return wp_remote_post( $fullEndpoint, $params );
	}

	/**
	 * Get the installments.
	 *
	 * @param float $amount Order amount.
	 *
	 * @return array
	 */
	public function get_installments( $amount ) {
		// Set the installment data.
		$data = array(
			'amount'            => $amount * 100,
			'interest_rate'     => $this->get_interest_rate(),
			'max_installments'  => $this->gateway->max_installment,
			'free_installments' => $this->gateway->free_installments,
		);

		$_installments = $this->calculateInstallments($data);

		if ( isset( $_installments['installments'] ) ) {
			$installments = $_installments['installments'];

			return $installments;
		}

		return array();
	}

	/**
	 * Calculate amount of installments
	 *
	 * @param $data
	 *
	 * @return array
	 */
	public function calculateInstallments($data)
	{
		$interestRate = $data["interest_rate"]/100;

		$parcels = [];
		for($i = 1; $i <= $data["max_installments"]; $i++) {
			$parcel = [];
			$parcel["installment"] = $i;


			if($i <= $data["free_installments"] || $interestRate <= 0) {
				$parcelValue = $data["amount"] / $i;
				$parcel["amount"] = $data["amount"];
				$parcel["installment_amount"] = $parcelValue;
			} else {
				$parcelWithInterests = round($data["amount"] * $interestRate / (1 - pow(1 + $interestRate, -$i)));

				$parcel["amount"] = $i * $parcelWithInterests;
				$parcel["installment_amount"] = $parcelWithInterests;
			}

			$parcels["$i"] = $parcel;
		}

		return ["installments" => $parcels];
	}

	/**
	 * Get max installment.
	 *
	 * @param float $amount Order amount.
	 *
	 * @return int
	 */
	public function get_max_installment( $amount ) {
		$installments         = $this->get_installments( $amount );
		$smallest_installment = $this->get_smallest_installment();
		$max                  = 1;

		foreach ( $installments as $number => $installment ) {
			if ( $smallest_installment > $installment['installment_amount'] ) {
				break;
			}

			$max = $number;
		}

		if($max > $this->gateway->max_installment) {
			return $this->gateway->max_installment;
		}

		return $max;
	}

	/**
	 * Generate the transaction data.
	 *
	 * @param  WC_Order $order  Order data.
	 * @param  array    $posted Form posted data.
	 *
	 * @return array            Transaction data.
	 */
	public function generate_transaction_data( $order, $posted ) {
		$errors = [
			"errors" => []
		];

		// Validando telefone
		$phone = $this->only_numbers($order->billing_phone);
		if(strlen($phone) == 10) {
			$phone = sprintf("(%s)%s-%s",
				substr($phone, 0, 2),
				substr($phone, 2, 4),
				substr($phone, 6, 4));
		} elseif(strlen($phone) == 11) {
			$phone = sprintf("(%s)%s-%s",
				substr($phone, 0, 2),
				substr($phone, 2, 5),
				substr($phone, 7, 4));
		} else {
			$errors["errors"][] = "O número de telefone não está completo.";
		}

		// Validando número do endereço
		$billingNumber = $this->only_numbers($order->billing_number);
		if(!strlen($billingNumber)) {
			$errors["errors"][] = "O número do endereço não é válido.";
		}

		// Validando CEP
		if(strlen($this->only_numbers($order->billing_postcode)) !== 8) {
			$errors["errors"][] = "O CEP do endereço não é válido.";
		}

		$data = array(
            "capture"  => true,
			"method"   => "credit",
			"installments" => 1,
            "value"    => $order->get_total() * 100,
            "customer" => array(
                "name" => trim( $order->billing_first_name . ' ' . $order->billing_last_name ),
				"email" => $order->billing_email,
				"cpf" => $order->billing_cpf,
				"phone" => $phone,
				"cep" => $order->billing_postcode,
				"address" => $order->billing_address_1,
				"number" => $billingNumber,
				"district" => $order->billing_neighborhood,
				"city" => $order->billing_city,
				"state" => $order->billing_state,
				"country" => "BR"
            )
		);

		if(count($posted)) {
			$data["card"] = [
				"number"    => $this->only_numbers($posted["card_number"]),
                "holder"    => trim(remove_accents($posted["card_holder"])),
                "expiration"=> str_replace(' ', '', $posted["card_expiration"]),
                "cvv"       => $posted["card_cvv"]
			];
		}

		$data = array_merge($data, $errors);

		if ( 'cefispay-credit-card' === $this->gateway->id ) {
			//Special processing for credit card
		} elseif ( 'cefispay-banking-ticket' === $this->gateway->id ) {
			//Special processing for banking ticket
		}

		// Add filter for Third Party plugins.
		return apply_filters( 'wc_cefispay_transaction_data', $data , $order );
	}

	/**
	 * Get customer data from checkout pay page.
	 *
	 * @return array
	 */
	public function get_customer_data_from_checkout_pay_page() {
		global $wp;

		$order    = wc_get_order( (int) $wp->query_vars['order-pay'] );
		$data     = $this->generate_transaction_data( $order, array() );
		$customer = array();

		if ( empty( $data['customer'] ) ) {
			return $customer;
		}

		$_customer = $data['customer'];
		$customer['customerName']  = $_customer['name'];
		$customer['customerEmail'] = $_customer['email'];

		if ( isset( $_customer['document_number'] ) ) {
			$customer['customerDocumentNumber'] = $_customer['document_number'];
		}

		if ( isset( $_customer['address'] ) ) {
			$customer['customerAddressStreet']        = $_customer['address']['street'];
			$customer['customerAddressComplementary'] = $_customer['address']['complementary'];
			$customer['customerAddressZipcode']       = $_customer['address']['zipcode'];

			if ( isset( $_customer['address']['street_number'] ) ) {
				$customer['customerAddressStreetNumber'] = $_customer['address']['street_number'];
			}
			if ( isset( $_customer['address']['neighborhood'] ) ) {
				$customer['customerAddressNeighborhood'] = $_customer['address']['neighborhood'];
			}
		}

		if ( isset( $_customer['phone'] ) ) {
			$customer['customerPhoneDdd']    = $_customer['phone']['ddd'];
			$customer['customerPhoneNumber'] = $_customer['phone']['number'];
		}

		return $customer;
	}

	/**
	 * Do the transaction.
	 *
	 * @param  WC_Order $order Order data.
	 * @param  array    $args  Transaction args.
	 * @param  string   $token Checkout token.
	 *
	 * @return array           Response data.
	 */
	public function do_transaction( $order, $args) {
		if ( 'yes' === $this->gateway->debug ) {
			$this->gateway->log->add( $this->gateway->id, 'Doing a transaction for order ' . $order->get_order_number() . '...' );

			$logParams = $args;
			unset($logParams["card"]);

			$this->gateway->log->add( $this->gateway->id, 'POST args: ' . json_encode($logParams) );
		}

		$response = $this->do_request( 'payments', 'POST', $args);

		if ( is_wp_error( $response ) ) {
			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'WP_Error in doing the transaction: ' . $response->get_error_message() );
			}

			return array();
		} else {
			$data = json_decode( $response['body'], true );

			if ( isset( $data['errors'] ) ) {
				if ( 'yes' === $this->gateway->debug ) {
					$this->gateway->log->add( $this->gateway->id, 'Failed to make the transaction: ' . print_r( $response, true ) );
				}

				return $data;
			}

			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'Transaction completed successfully! The transaction response is: ' . print_r( $data, true ) );
			}

			return $data["payment"];
		}
	}

	/**
	 * Get transaction data.
	 *
	 * @param  WC_Order $order Order data.
	 * @param  string   $token Checkout token.
	 *
	 * @return array           Response data.
	 */
	public function get_transaction_data( $order, $paymentId ) {
		if ( 'yes' === $this->gateway->debug ) {
			$this->gateway->log->add( $this->gateway->id, 'Getting transaction data for order ' . $order->get_order_number() . '...' );
		}

		$response = $this->do_request( 'payments/' . $paymentId, 'GET');

		if ( is_wp_error( $response ) ) {
			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'WP_Error in getting transaction data: ' . $response->get_error_message() );
			}

			return array();
		} else {
			$data = json_decode( $response['body'], true );

			if ( isset( $data['errors'] ) ) {
				if ( 'yes' === $this->gateway->debug ) {
					$this->gateway->log->add( $this->gateway->id, 'Failed to get transaction data: ' . print_r( $response, true ) );
				}

				return $data["data"];
			}

			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'Transaction data obtained successfully!' );
			}

			return $data["data"];
		}
	}

	/**
	 * Refund the order.
	 *
	 * @param  WC_Order $order Order data.
	 * @param  float    $amount Amount to refund.
	 *
	 * @return bool     Successfully refunded.
	 */
	public function do_refund( $order_id, $amount ) {
		$order    = wc_get_order( $order_id );
		$transaction_id  = get_post_meta( $order_id, '_wc_cefispay_transaction_id', true );
		$endpoint = 'transactions/' . $transaction_id . '/refund';
		$data = array (
			'api_key' => $this->gateway->api_key,
		);

		if ( 'yes' === $this->gateway->debug ) {
			$this->gateway->log->add( $this->gateway->id, 'Starting refunding for order. ID: ' . $order->get_order_number() . '...' );
		}

		if ( ! in_array( $order->get_status(), array( 'processing', 'completed' ), true ) ) {
			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'Can\'t refund unpaid order. ID: ' . $order->get_order_number() );
			}

			return false;
		}

		if ( $order->get_total() < $amount ) {
			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'Can\'t refund more than the paid amount. ID: ' . $order->get_order_number() );
			}

			return false;
		}

		if ( $amount <= 0 ) {
			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'Can\'t refund when amount is zero or negative. ID: ' . $order->get_order_number() );
			}

			return false;
		}

		$is_partially_refund = $amount < $order->get_total();

		if ( $is_partially_refund ){
			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'Refunding order partially. ID: ' . $order->get_order_number() . '...' );
				$this->gateway->log->add( $this->gateway->id, 'Order total: ' . $order->get_total() . ', Refund total: ' . $amount );
			}

			$data['amount'] = $amount * 100;
		}

		$response = $this->do_request( $endpoint, 'POST', $data );

		if ( is_wp_error( $response ) ) {
			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'Error doing refund: ' . $response->get_error_message() );
			}

			return false;
		}

		$response_data = json_decode( $response['body'], true );

		if ( isset( $response_data['errors'] ) ) {
			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'Failed to make the refund: ' . print_r( $response, true ) );
			}

			return false;
		}

		return true;
	}

	/**
	 * Do the transaction.
	 *
	 * @param  WC_Order $order Order data.
	 * @param  string   $token Checkout token.
	 *
	 * @return array           Response data.
	 */
	public function cancel_transaction( $order, $token ) {
		if ( 'yes' === $this->gateway->debug ) {
			$this->gateway->log->add( $this->gateway->id, 'Cancelling transaction for order ' . $order->get_order_number() . '...' );
		}

		$endpoint = 'payment/reversal';

		$response = $this->do_request( $endpoint, 'POST', array( "payment" => ["id" => $token] ) );

		if ( is_wp_error( $response ) ) {
			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'WP_Error in doing the transaction cancellation: ' . $response->get_error_message() );
			}

			return array();
		} else {
			$data = json_decode( $response['body'], true );

			if ( isset( $data['errors'] ) ) {
				if ( 'yes' === $this->gateway->debug ) {
					$this->gateway->log->add( $this->gateway->id, 'Failed to cancel the transaction: ' . print_r( $response, true ) );
				}

				return $data;
			}

			if ( 'yes' === $this->gateway->debug ) {
				$this->gateway->log->add( $this->gateway->id, 'Transaction canceled successfully! The response is: ' . print_r( $data, true ) );
			}

			return $data;
		}
	}

	/**
	 * Get card brand name.
	 *
	 * @param string $brand Card brand.
	 * @return string
	 */
	protected function get_card_brand_name( $brand ) {
		$names = array(
			'visa'       => __( 'Visa', 'woocommerce-cefispay' ),
			'mastercard' => __( 'MasterCard', 'woocommerce-cefispay' ),
			'amex'       => __( 'American Express', 'woocommerce-cefispay' ),
			'aura'       => __( 'Aura', 'woocommerce-cefispay' ),
			'jcb'        => __( 'JCB', 'woocommerce-cefispay' ),
			'diners'     => __( 'Diners', 'woocommerce-cefispay' ),
			'elo'        => __( 'Elo', 'woocommerce-cefispay' ),
			'hipercard'  => __( 'Hipercard', 'woocommerce-cefispay' ),
			'discover'   => __( 'Discover', 'woocommerce-cefispay' ),
		);

		return isset( $names[ $brand ] ) ? $names[ $brand ] : $brand;
	}

	/**
	 * Save order meta fields.
	 * Save fields as meta data to display on order's admin screen.
	 *
	 * @param int   $id Order ID.
	 * @param array $data Order data.
	 */
	protected function save_order_meta_fields( $id, $data ) {

		// Transaction data.
		$payment_data = array_map(
			'sanitize_text_field',
			array(
				'payment_method'  	=> $data['method'],
				'card_id'  			=> $data['card_id'],
				'customer_id'  		=> $data['customer_id']
			)
		);

		// Meta data.
		$meta_data = array(
			__( 'Credit Card', 'woocommerce-cefispay' )		=> $this->get_card_brand_name( sanitize_text_field( $data['card']['brand'] ) ),
			__( 'Total paid', 'woocommerce-cefispay' )    	=> number_format( intval( $data['amount'] ) / 100, wc_get_price_decimals(), wc_get_price_decimal_separator(), wc_get_price_thousand_separator() ),
			'_wc_cefispay_transaction_data'                	=> $payment_data,
			'_wc_cefispay_transaction_id'                 	=> intval( $data['id'] ),
			'_transaction_id'                              	=> intval( $data['id'] )
		);

		$order = wc_get_order( $id );

		// WooCommerce 3.0 or later.
		if ( ! method_exists( $order, 'update_meta_data' ) ) {
			foreach ( $meta_data as $key => $value ) {
				update_post_meta( $id, $key, $value );
			}
		} else {
			foreach ( $meta_data as $key => $value ) {
				$order->update_meta_data( $key, $value );
			}

			$order->save();
		}
	}

	/**
	 * Process the order status.
	 *
	 * @param WC_Order $order  Order data.
	 * @param int   $transaction_id Transaction id.
	 */
	protected function update_transaction_id( $order, $transaction_id) {
		if($transaction_id) {
			$order->set_transaction_id($transaction_id);
			$order->save();
		}
	}

	/**
	 * Process regular payment.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @return array Redirect data.
	 */
	public function process_regular_payment( $order_id ) {
		$order = wc_get_order( $order_id );

		$is_checkout_cefispay = isset( $this->gateway->checkout ) && 'yes' === $this->gateway->checkout;

		if($is_checkout_cefispay) {
			if ( ! empty( $_POST['cefispay_checkout_token'] ) ) {
				$token = sanitize_text_field( wp_unslash( $_POST['cefispay_checkout_token'] ) );

				// Fazer requisição na API da CEFIS Pay e buscar o pagamento
				$transaction = $this->get_transaction_data( $order, $token );
			} else {
				$transaction = array( 'errors' => array( array( 'message' => __( 'Dados da transação não encontrados, por favor, entre em contato conosco.', 'woocommerce-cefispay' ) ) ) );
			}
		} else {
			$data = $this->generate_transaction_data( $order, $_POST );

			if($data["errors"]) {
				foreach ( $data["errors"] as $error ) {
					wc_add_notice( $error, 'error' );
				}
				return array(
					'result' => 'fail',
				);
			} else {
				$transaction = $this->do_transaction( $order, $data );

				if($transaction["errors"]) {
					wc_add_notice( "Houve um erro inesperado ao realizar a operação.", 'error' );
					return array(
						'result' => 'fail',
					);
				}
			}
		}

		$this->save_order_meta_fields( $order_id, $transaction );

		$this->process_order_status( $order, $transaction['status'] );

		$this->update_transaction_id( $order, $transaction["id"] );

		if($transaction['status'] === 'paid') {
			// Empty the cart.
			WC()->cart->empty_cart();

			// Redirect to thanks page.
			return array(
				'result'   => 'success',
				'redirect' => $this->gateway->get_return_url( $order ),
			);
		} else {
			wc_add_notice( "O pagamento não foi autorizado, verifique TODOS os dados e o limite do cartão e tente novamente.", 'error' );
			return array(
				'result' => 'fail',
			);
		}
	}

	/**
	 * IPN handler.
	 */
	public function ipn_handler() {
		wp_die( esc_html__( 'CEFIS Pay Request Failure', 'woocommerce-cefispay' ), '', array( 'response' => 401 ) );
	}

	/**
	 * Process the order status.
	 *
	 * @param WC_Order $order  Order data.
	 * @param string   $status Transaction status.
	 */
	public function process_order_status( $order, $status ) {
		if ( 'yes' === $this->gateway->debug ) {
			$this->gateway->log->add( $this->gateway->id, 'Payment status for order ' . $order->get_order_number() . ' is now: ' . $status );
		}

		switch ( $status ) {
			case 'paid' :
				if ( ! in_array( $order->get_status(), array( 'processing', 'completed' ), true ) ) {
					$order->add_order_note( __( 'CEFIS Pay: Transação paga.', 'woocommerce-cefispay' ) );
				}

				// Changing the order for processing and reduces the stock.
				$order->payment_complete();

				break;
			case 'unauthorized' :
				$order->update_status( 'failed', __( 'CEFIS Pay: Transação não autorizada.', 'woocommerce-cefispay' ) );
				break;
			case 'reversed' :
				$order->update_status( 'refunded', __( 'CEFIS Pay: A transação foi cancelada/estornada.', 'woocommerce-cefispay' ) );
				break;
			default :
				break;
		}
	}
}
