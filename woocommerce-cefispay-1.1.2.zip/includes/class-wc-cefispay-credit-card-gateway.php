<?php
/**
 * CEFIS Pay Credit Card gateway
 *
 * @package WooCommerce_CefisPay/Gateway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WC_CefisPay_Credit_Card_Gateway class.
 *
 * @extends WC_Payment_Gateway
 */
class WC_CefisPay_Credit_Card_Gateway extends WC_Payment_Gateway {

	/** @var WC_CefisPay_API */
	public $api;

	/**
	 * Constructor for the gateway.
	 */
	public function __construct() {
		$this->id                   = 'cefispay-credit-card';
		$this->icon                 = 'https://payments.cefis.com.br/img/cefispay_logo_color_white.png';
		$this->has_fields           = true;
		$this->method_title         = __( 'CEFIS Pay - Cartão de Crédito', 'woocommerce-cefispay' );
		$this->method_description   = __( 'Aceite pagamentos por cartão de crédito usando a CEFIS Pay.', 'woocommerce-cefispay' );
		$this->view_transaction_url = 'https://app.cefispay.com.br/#/transactions/%s';
		$this->supports           	= array(
			'refunds'
		);

		// Load the form fields.
		$this->init_form_fields();

		// Load the settings.
		$this->init_settings();

		// Define user set variables.
		$this->title                  = $this->get_option( 'title' );
		$this->description            = $this->get_option( 'description' );
		$this->api_key                = $this->get_option( 'api_key' );
		$this->merchant_id         	  = $this->get_option( 'merchant_id' );
		$this->checkout               = $this->get_option( 'checkout' );
		$this->register_refused_order = true;
		$this->max_installment        = $this->get_option( 'max_installment' );
		$this->smallest_installment   = $this->get_option( 'smallest_installment' );
		$this->interest_rate          = $this->get_option( 'interest_rate', '0' );
		$this->free_installments      = $this->get_option( 'free_installments', '1' );
		$this->debug                  = $this->get_option( 'debug' );

		// Active logs.
		if ( 'yes' === $this->debug ) {
			$this->log = new WC_Logger();
		}

		// Set the API.
		$this->api = new WC_CefisPay_API( $this );

		// Actions.
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'checkout_scripts' ) );
		add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
		add_action( 'woocommerce_email_after_order_table', array( $this, 'email_instructions' ), 10, 3 );
		add_action( 'woocommerce_api_wc_cefispay_credit_card_gateway', array( $this, 'ipn_handler' ) );
	}

	/**
	 * Admin page.
	 */
	public function admin_options() {
		include dirname( __FILE__ ) . '/admin/views/html-admin-page.php';
	}

	/**
	 * Check if the gateway is available to take payments.
	 *
	 * @return bool
	 */
	public function is_available() {
		return parent::is_available() && ! empty( $this->api_key ) && $this->api->using_supported_currency();
	}

	/**
	 * Settings fields.
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled' => array(
				'title'   => __( 'Habilitar/Desabilitar', 'woocommerce-cefispay' ),
				'type'    => 'checkbox',
				'label'   => __( 'Habilitar cartão de crédito via CEFIS Pay', 'woocommerce-cefispay' ),
				'default' => 'no',
			),
			'title' => array(
				'title'       => __( 'Título', 'woocommerce-cefispay' ),
				'type'        => 'text',
				'description' => __( 'Controla o título que o usuário vê durante o checkout.', 'woocommerce-cefispay' ),
				'desc_tip'    => true,
				'default'     => __( 'Credit Card', 'woocommerce-cefispay' ),
			),
			'description' => array(
				'title'       => __( 'Descrição', 'woocommerce-cefispay' ),
				'type'        => 'textarea',
				'description' => __( 'Controla a descrição que o usuário vê durante o checkout.', 'woocommerce-cefispay' ),
				'desc_tip'    => true,
				'default'     => __( 'Pay with Credit Card', 'woocommerce-cefispay' ),
			),
			'integration' => array(
				'title'       => __( 'Configurações de Integração', 'woocommerce-cefispay' ),
				'type'        => 'title',
				'description' => '',
			),
			'api_key' => array(
				'title'             => __( 'CEFIS Pay API Key', 'woocommerce-cefispay' ),
				'type'              => 'text',
				'description'       => sprintf( __( 'Insira sua API Key CEFIS Pay. Para solicitar sua API key por favor entre em contato em %s.', 'woocommerce-cefispay' ), '<a href="mailto:ti@cefispay.com.br">ti@cefispay.com.br</a>' ),
				'default'           => '',
				'custom_attributes' => array(
					'required' => 'required',
				),
			),
			'merchant_id' => array(
				'title'             => __( 'CEFIS Pay Merchant ID', 'woocommerce-cefispay' ),
				'type'              => 'text',
				'description'       => sprintf( __( 'Insira seu Merchant ID CEFIS Pay. Para solicitar sua API key por favor entre em contato em %s.', 'woocommerce-cefispay' ), '<a href="mailto:ti@cefispay.com.br">ti@cefispay.com.br</a>' ),
				'default'           => '',
				'custom_attributes' => array(
					'required' => 'required',
				),
			),
			'checkout' => array(
				'title'       => __( 'Checkout CEFIS Pay', 'woocommerce-cefispay' ),
				'type'        => 'checkbox',
				'label'       => __( 'Habilitar checkout CEFIS Pay', 'woocommerce-cefispay' ),
				'default'     => 'no',
				'desc_tip'    => true,
				'description' => __( "Quando habilitado, abre uma janela modal da CEFIS Pay para receber os dados de cartão de crédito.", 'woocommerce-cefispay' ),
			),
			'installments' => array(
				'title'       => __( 'Parcelamento', 'woocommerce-cefispay' ),
				'type'        => 'title',
				'description' => '',
			),
			'max_installment' => array(
				'title'       => __( 'Número de parcelas', 'woocommerce-cefispay' ),
				'type'        => 'select',
				'class'       => 'wc-enhanced-select',
				'default'     => '12',
				'description' => __( 'Número máximo de parcelas que o usuário poderá selecionar ao pagar com o cartão de crédito.', 'woocommerce-cefispay' ),
				'desc_tip'    => true,
				'options'     => array(
					'1'  => '1',
					'2'  => '2',
					'3'  => '3',
					'4'  => '4',
					'5'  => '5',
					'6'  => '6',
					'7'  => '7',
					'8'  => '8',
					'9'  => '9',
					'10' => '10',
					'11' => '11',
					'12' => '12',
				),
			),
			'smallest_installment' => array(
				'title'       => __( 'Menor parcela', 'woocommerce-cefispay' ),
				'type'        => 'text',
				'description' => __( 'Insira qual deve ser o valor mínimo da parcela em caso de parcelamento. Nota: não pode ser menor que 5.', 'woocommerce-cefispay' ),
				'desc_tip'    => true,
				'default'     => '5',
			),
			'interest_rate' => array(
				'title'       => __( 'Taxa de juros do parcelamento', 'woocommerce-cefispay' ),
				'type'        => 'text',
				'description' => __( 'A taxa de juros que será adicionada a cada parcela. Nota: use 0 para não cobrar juros.', 'woocommerce-cefispay' ),
				'desc_tip'    => true,
				'default'     => '0',
			),
			'free_installments' => array(
				'title'       => __( 'Parcelas sem juros', 'woocommerce-cefispay' ),
				'type'        => 'select',
				'class'       => 'wc-enhanced-select',
				'default'     => '1',
				'description' => __( 'Numero de parcelas que não terão juros.', 'woocommerce-cefispay' ),
				'desc_tip'    => true,
				'options'     => array(
					'0'  => _x( 'None', 'no free installments', 'woocommerce-cefispay' ),
					'1'  => '1',
					'2'  => '2',
					'3'  => '3',
					'4'  => '4',
					'5'  => '5',
					'6'  => '6',
					'7'  => '7',
					'8'  => '8',
					'9'  => '9',
					'10' => '10',
					'11' => '11',
					'12' => '12',
				),
			),
			'testing' => array(
				'title'       => __( 'Log', 'woocommerce-cefispay' ),
				'type'        => 'title',
				'description' => '',
			),
			'debug' => array(
				'title'       => __( 'Debug Log', 'woocommerce-cefispay' ),
				'type'        => 'checkbox',
				'label'       => __( 'Habilitar registro de logs', 'woocommerce-cefispay' ),
				'default'     => 'no',
				'description' => sprintf( __( 'Registra eventos da CEFIS Pay, como requisições de API. Você pode ver o log em %s', 'woocommerce-cefispay' ), '<a href="' . esc_url( admin_url( 'admin.php?page=wc-status&tab=logs&log_file=' . esc_attr( $this->id ) . '-' . sanitize_file_name( wp_hash( $this->id ) ) . '.log' ) ) . '">' . __( 'System Status &gt; Logs', 'woocommerce-cefispay' ) . '</a>' ),
			),
		);
	}

	/**
	 * Checkout scripts.
	 */
	public function checkout_scripts() {
		if ( is_checkout() ) {
			if ( 'yes' === $this->checkout ) {
				$customer = array();

				wp_enqueue_script( 'cefispay-checkout-library', $this->api->get_checkout_js_url(), array( 'jquery' ), null );
				wp_enqueue_script( 'sentry.io-library', "https://browser.sentry-cdn.com/6.0.2/bundle.min.js", array( 'jquery' ), null );
				wp_enqueue_script( 'cefispay-checkout', plugins_url( 'assets/js/checkout.js', plugin_dir_path( __FILE__ ) ), array( 'jquery', 'jquery-blockui', 'cefispay-checkout-library' ), WC_CefisPay::VERSION, true );

				if ( is_checkout_pay_page() ) {
					$customer = $this->api->get_customer_data_from_checkout_pay_page();
				}

				wp_localize_script(
					'cefispay-checkout',
					'wcCefisPayParams',
					array(
						'merchantId'             => $this->merchant_id,
						'interestRate'           => $this->api->get_interest_rate(),
						'freeInstallments'       => $this->free_installments,
						'postbackUrl'            => WC()->api_request_url( get_class( $this ) ),
						'customerFields'         => $customer,
						'checkoutPayPage'        => ! empty( $customer ),
						'uiColor'                => apply_filters( 'wc_cefispay_checkout_ui_color', '#1a6ee1' ),
						'register_refused_order' => $this->register_refused_order,
					)
				);
			} else {
				wp_enqueue_script( 'wc-credit-card-form' );
				wp_enqueue_script( 'sentry.io-library', "https://browser.sentry-cdn.com/6.0.2/bundle.min.js", array( 'jquery' ), null );
				wp_enqueue_script( 'cefispay-credit-card', plugins_url( 'assets/js/credit-card.js', plugin_dir_path( __FILE__ ) ), array( 'jquery', 'jquery-blockui' ), WC_CefisPay::VERSION, true );

				wp_localize_script(
					'cefispay-credit-card',
					'wcCefisPayParams',
					array(
						'merchantId'	=> $this->merchant_id,
					)
				);
			}
		}
	}

	/**
	 * Payment fields.
	 */
	public function payment_fields() {
		if ( $description = $this->get_description() ) {
			echo wp_kses_post( wpautop( wptexturize( $description ) ) );
		}

		$cart_total = $this->get_order_total();

		if ( 'no' === $this->checkout ) {
			$installments = $this->api->get_installments( $cart_total );

			wc_get_template(
				'credit-card/payment-form.php',
				array(
					'cart_total'           => $cart_total,
					'max_installment'      => $this->max_installment,
					'smallest_installment' => $this->api->get_smallest_installment(),
					'installments'         => $installments,
				),
				'woocommerce/cefispay/',
				WC_CefisPay::get_templates_path()
			);
		} else {
			echo '<div id="cefispay-checkout-params" ';
			echo 'data-total="' . esc_attr( $cart_total * 100 ) . '" ';
			echo 'data-max_installment="' . esc_attr( apply_filters( 'wc_cefispay_checkout_credit_card_max_installments', $this->api->get_max_installment( $cart_total ) ) ) . '"';
			echo '></div>';
		}
	}

	/**
	 * Process the payment.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @return array Redirect data.
	 */
	public function process_payment( $order_id ) {
		return $this->api->process_regular_payment( $order_id );
	}

	/**
	 * Refund the payment.
	 *
	 * @param int $order_id Order ID.
	 * @param float $amount Amount to refund.
	 * @param string $reason Reason to refund.
	 *
	 * @return bool Successfully refunded.
	 */

	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		return $this->api->do_refund( $order_id , $amount );
	}

	/**
	 * Thank You page message.
	 *
	 * @param int $order_id Order ID.
	 */
	public function thankyou_page( $order_id ) {
		$order = wc_get_order( $order_id );
		$data  = get_post_meta( $order_id, '_wc_cefispay_transaction_data', true );

		if ( isset( $data['installments'] ) && in_array( $order->get_status(), array( 'processing', 'on-hold' ), true ) ) {
			wc_get_template(
				'credit-card/payment-instructions.php',
				array(
					'card_brand'   => $data['card_brand'],
					'installments' => $data['installments'],
				),
				'woocommerce/cefispay/',
				WC_CefisPay::get_templates_path()
			);
		}
	}

	/**
	 * Add content to the WC emails.
	 *
	 * @param  object $order         Order object.
	 * @param  bool   $sent_to_admin Send to admin.
	 * @param  bool   $plain_text    Plain text or HTML.
	 *
	 * @return string                Payment instructions.
	 */
	public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
		if ( $sent_to_admin || ! in_array( $order->get_status(), array( 'processing', 'on-hold' ), true ) || $this->id !== $order->payment_method ) {
			return;
		}

		$data = get_post_meta( $order->id, '_wc_cefispay_transaction_data', true );

		if ( isset( $data['installments'] ) ) {
			$email_type = $plain_text ? 'plain' : 'html';

			wc_get_template(
				'credit-card/emails/' . $email_type . '-instructions.php',
				array(
					'card_brand'   => $data['card_brand'],
					'installments' => $data['installments'],
				),
				'woocommerce/cefispay/',
				WC_CefisPay::get_templates_path()
			);
		}
	}

	/**
	 * IPN handler.
	 */
	public function ipn_handler() {
		$this->api->ipn_handler();
	}
}
