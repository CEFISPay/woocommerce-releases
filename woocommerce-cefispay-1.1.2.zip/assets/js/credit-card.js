/* global wcCefisPayParams */
(function( $ ) {
    'use strict';

    $( function() {

		Sentry.init({
			dsn: 'https://66aa417fa3ee401c9c0224c25aa77a82@o512148.ingest.sentry.io/5611068',
			tracesSampleRate: 1.0,
		});

        /**
        * Process the credit card data when submit the checkout form.
        */
        $( 'body' ).on( 'click', '#place_order', function() {
            if ( ! $( '#payment_method_cefispay-credit-card' ).is( ':checked' ) ) {
                return true;
            }

            var form       = $( 'form.checkout, form#order_review' ),
            creditCard     = {},
            creditCardForm = $( '#cefispay-credit-cart-form', form ),
            errors         = null,
            errorHtml      = '';

            // Lock the checkout form.
            form.addClass( 'processing' );

            // Set the Credit card data.
            creditCard.cardHolderName      	= $( '#cefispay-card-holder-name', form ).val();
            creditCard.cardExpiration		= $( '#cefispay-card-expiry', form ).val();
            creditCard.cardNumber          	= $( '#cefispay-card-number', form ).val();
            creditCard.cardCVV             	= $( '#cefispay-card-cvc', form ).val();

            // Get the errors.
			errors = validateCreditCard(creditCard);

			console.log(errors);

            // Display the errors in credit card form.
            if ( ! $.isEmptyObject( errors ) ) {
                form.removeClass( 'processing' );
                $( '.woocommerce-error', creditCardForm ).remove();

                errorHtml += '<ul>';
                $.each( errors, function ( key, value ) {
                    errorHtml += '<li>' + value + '</li>';
                });
                errorHtml += '</ul>';

                creditCardForm.prepend( '<div class="woocommerce-error">' + errorHtml + '</div>' );
            } else {
                form.removeClass( 'processing' );
                $( '.woocommerce-error', creditCardForm ).remove();

                // Submit the form.
                form.submit();
            }

            return false;
        });

        function validateCreditCard(creditCard) {
			var errors = [];

			if(!creditCard.cardHolderName) {
				errors.push('Insira o titular do cartão.');
			} else if(creditCard.cardHolderName.trim().split(" ").length < 2) {
				errors.push('Insira o nome completo do titular.');
			}

			if(!creditCard.cardNumber) {
				errors.push('Insira o número do cartão.');
			} else if(creditCard.cardNumber.length < 17) {
				errors.push('O número do cartão está incompleto.');
			}

			if(!creditCard.cardExpiration) {
				errors.push('Insira a expiração do cartão.');
			} else {
				if(creditCard.cardExpiration.length !== 9) {
					errors.push('A data de expiração está incompleta. Use o formato MM/AAAA.');
				} else {
					var parts = creditCard.cardExpiration.replace(/\s+/g, '').split("/")
					var currentYear = new Date().getFullYear();
					if(parseInt(parts[0]) < 1 || parseInt(parts[0]) > 12) {
						errors.push('O mês de expiração não é válido.');
					}
					if(parseInt(parts[1]) < currentYear || parseInt(parts[1]) > (currentYear+15)) {
						errors.push('O ano de expiração não é válido.');
					}
				}
			}

			if(!creditCard.cardCVV) {
				errors.push('Insira o cvv do cartão.');
			} else if(creditCard.cardCVV.length < 3){
				errors.push('Insira corretamente o CVV.');
			}

			return errors;
		}
    });

}( jQuery ));
